//All of the long and annoying crap that would make the main JS file ugly
function Geometry() {
	var geometry = new THREE.PlaneBufferGeometry(70, 70)
	var material = new THREE.MeshBasicMaterial( {color: 0x00ff00} )
	var grass = new THREE.Mesh( geometry, material )
	scene.add(grass)

  var geometry = new THREE.PlaneBufferGeometry(100, 10)
  var material = new THREE.MeshBasicMaterial( {color: 0x00cc00} )
  var hill1 = new THREE.Mesh( geometry, material )
  scene.add(hill1)
  hill1.rotation.x = -0.25*Math.PI
  hill1.position.z = -35
  hill1.position.y = -1.5

  var geometry = new THREE.PlaneBufferGeometry(10, 100)
  var material = new THREE.MeshBasicMaterial( {color: 0x00dd00} )
  var hill2 = new THREE.Mesh( geometry, material )
  scene.add(hill2)
  hill2.rotation.y = 0.25*Math.PI
  hill2.rotation.x = -0.5*Math.PI
  hill2.position.x = -35
  hill2.position.y = -1.5

  var geometry = new THREE.PlaneBufferGeometry(100, 10)
  var material = new THREE.MeshBasicMaterial( {color: 0x00ee00} )
  var hill3 = new THREE.Mesh( geometry, material )
  scene.add(hill3)
  hill3.rotation.y = Math.PI
  hill3.rotation.x = 0.25*Math.PI
  hill3.position.z = 35
  hill3.position.y = -1.5

  var geometry = new THREE.PlaneBufferGeometry(10, 100)
  var material = new THREE.MeshBasicMaterial( {color: 0x00dd00} )
  var hill4 = new THREE.Mesh( geometry, material )
  scene.add(hill4)
  hill4.rotation.y = 1.25*Math.PI
  hill4.rotation.x = 0.5*Math.PI
  hill4.position.x = 35
  hill4.position.y = -1.5

  grass.position.y -= 5
  grass.rotation.x -= (0.5*Math.PI)


  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xbb8844} );
  var post00 = new THREE.Mesh( geometry, material );
  scene.add( post00 );
  post00.position.x = -30
  post00.position.y = -2.5
  post00.position.z = -30

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xbb8844} );
  var post03 = new THREE.Mesh( geometry, material );
  scene.add( post03 );
  post03.position.x = 30
  post03.position.y = -2.5
  post03.position.z = -30

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xbb8844} );
  var post30 = new THREE.Mesh( geometry, material );
  scene.add( post30 );
  post30.position.x = -30
  post30.position.y = -2.5
  post30.position.z = 30

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xbb8844} );
  var post33 = new THREE.Mesh( geometry, material );
  scene.add( post33 );
  post33.position.x = 30
  post33.position.y = -2.5
  post33.position.z = 30

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xbb8844} );
  var post01 = new THREE.Mesh( geometry, material );
  scene.add( post01 );
  post01.position.x = -10
  post01.position.y = -2.5
  post01.position.z = -30

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xbb8844} );
  var post02 = new THREE.Mesh( geometry, material );
  scene.add( post02 );
  post02.position.x = 10
  post02.position.y = -2.5
  post02.position.z = -30

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xbb8844} );
  var post13 = new THREE.Mesh( geometry, material );
  scene.add( post13 );
  post13.position.x = 30
  post13.position.y = -2.5
  post13.position.z = -10

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xbb8844} );
  var post23 = new THREE.Mesh( geometry, material );
  scene.add( post23 );
  post23.position.x = 30
  post23.position.y = -2.5
  post23.position.z = 10

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xbb8844} );
  var post10 = new THREE.Mesh( geometry, material );
  scene.add( post10 );
  post10.position.x = -30
  post10.position.y = -2.5
  post10.position.z = -10

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xbb8844} );
  var post20 = new THREE.Mesh( geometry, material );
  scene.add( post20 );
  post20.position.x = -30
  post20.position.y = -2.5
  post20.position.z = 10

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xbb8844} );
  var post31 = new THREE.Mesh( geometry, material );
  scene.add( post31 );
  post31.position.x = -10
  post31.position.y = -2.5
  post31.position.z = 30

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xbb8844} );
  var post32 = new THREE.Mesh( geometry, material );
  scene.add( post32 );
  post32.position.x = 10
  post32.position.y = -2.5
  post32.position.z = 30

  var geometry = new THREE.BoxGeometry( 61, 1, 1.1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xaa7733} );
  var beam00 = new THREE.Mesh( geometry, material );
  scene.add( beam00 );
  beam00.position.x = 0
  beam00.position.y = -2.1
  beam00.position.z = -30

  var geometry = new THREE.BoxGeometry( 1.1, 1, 61 );
  var material = new THREE.MeshBasicMaterial( {color: 0xaa7733} );
  var beam01 = new THREE.Mesh( geometry, material );
  scene.add( beam01 );
  beam01.position.x = -30
  beam01.position.y = -2.1
  beam01.position.z = 0

  var geometry = new THREE.BoxGeometry( 61, 1, 1.1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xaa7733} );
  var beam10 = new THREE.Mesh( geometry, material );
  scene.add( beam10 );
  beam10.position.x = 0
  beam10.position.y = -2.1
  beam10.position.z = 30

  var geometry = new THREE.BoxGeometry( 1.1, 1, 61 );
  var material = new THREE.MeshBasicMaterial( {color: 0xaa7733} );
  var beam11 = new THREE.Mesh( geometry, material );
  scene.add( beam11 );
  beam11.position.x = 30
  beam11.position.y = -2.1
  beam11.position.z = 0

  var geometry = new THREE.BoxGeometry( 15, 1, 15 );
  var material = new THREE.MeshBasicMaterial( {color: 0xa0a0a0} );
  var slab1 = new THREE.Mesh( geometry, material );
  scene.add( slab1 );
  slab1.position.x = 0
  slab1.position.y = -4
  slab1.position.z = 0

  var geometry = new THREE.PlaneBufferGeometry(3, 1.5)
  window.material1 = new THREE.MeshLambertMaterial({color: 0x000000, transparent: true})
  window.blackscreen = new THREE.Mesh(geometry, material1)
  scene.add(blackscreen)

  var geometry = new THREE.TorusGeometry(2, 0.4, 20, 200)
  var material = new THREE.MeshBasicMaterial({color: 0x888822})
  var lwheel = new THREE.Mesh(geometry, material)
  scene.add(lwheel)
  lwheel.position.y = -1.2
  lwheel.rotation.y = 0.5*Math.PI
  lwheel.position.x = 1.7
  lwheel.position.z = 0

  var geometry = new THREE.TorusGeometry(2, 0.4, 20, 200)
  var material = new THREE.MeshBasicMaterial({color: 0x888822})
  var rwheel = new THREE.Mesh(geometry, material)
  scene.add(rwheel)
  rwheel.position.y = -1.2
  rwheel.rotation.y = 0.5*Math.PI
  rwheel.position.x = -1.7
  rwheel.position.z = 0

  var geometry = new THREE.CylinderGeometry( 1.7, 1.7, 8, 32, 32, true);
  var material = new THREE.MeshBasicMaterial( {color: 0x666600} );
  var barrel = new THREE.Mesh( geometry, material );
  scene.add( barrel );
  barrel.rotation.x = 0.5*Math.PI
  barrel.position.y = -0.6
  barrel.position.z = 1.8

  var geometry = new THREE.SphereGeometry( 1.7, 32, 32 );
  var material = new THREE.MeshBasicMaterial( {color: 0x666600} );
  var barrelsphere = new THREE.Mesh( geometry, material );
  scene.add( barrelsphere );
  barrelsphere.position.y = -0.6
  barrelsphere.position.z = -2.2

  var geometry = new THREE.CircleGeometry( 1.7, 32 );
  var material = new THREE.MeshBasicMaterial( { color: 0x000000 } );
  var barrelcircle = new THREE.Mesh( geometry, material );
  scene.add( barrelcircle );
  barrelcircle.position.y = -0.6
  barrelcircle.position.z = 5.8

  var geometry = new THREE.CylinderGeometry( 0.2, 0.2, 4, 32, 32);
  var material = new THREE.MeshBasicMaterial( {color: 0x888822} );
  var spoke1 = new THREE.Mesh( geometry, material );
  scene.add( spoke1 );
  spoke1.position.x = -1.7
  spoke1.position.y = -1.2
  spoke1.position.z = 0

  var geometry = new THREE.CylinderGeometry( 0.2, 0.2, 4, 32, 32);
  var material = new THREE.MeshBasicMaterial( {color: 0x888822} );
  var spoke2 = new THREE.Mesh( geometry, material );
  scene.add( spoke2 );
  spoke2.position.x = -1.7
  spoke2.position.y = -1.2
  spoke2.position.z = 0
  spoke2.rotation.x = (1/3)*Math.PI

  var geometry = new THREE.CylinderGeometry( 0.2, 0.2, 4, 32, 32);
  var material = new THREE.MeshBasicMaterial( {color: 0x888822} );
  var spoke3 = new THREE.Mesh( geometry, material );
  scene.add( spoke3 );
  spoke3.position.x = -1.7
  spoke3.position.y = -1.2
  spoke3.position.z = 0
  spoke3.rotation.x = (2/3)*Math.PI

  var geometry = new THREE.CylinderGeometry( 0.2, 0.2, 4, 32, 32);
  var material = new THREE.MeshBasicMaterial( {color: 0x888822} );
  var spoke4 = new THREE.Mesh( geometry, material );
  scene.add( spoke4 );
  spoke4.position.x = 1.7
  spoke4.position.y = -1.2
  spoke4.position.z = 0

  var geometry = new THREE.CylinderGeometry( 0.2, 0.2, 4, 32, 32);
  var material = new THREE.MeshBasicMaterial( {color: 0x888822} );
  var spoke5 = new THREE.Mesh( geometry, material );
  scene.add( spoke5 );
  spoke5.position.x = 1.7
  spoke5.position.y = -1.2
  spoke5.position.z = 0
  spoke5.rotation.x = (1/3)*Math.PI

  var geometry = new THREE.CylinderGeometry( 0.2, 0.2, 4, 32, 32);
  var material = new THREE.MeshBasicMaterial( {color: 0x888822} );
  var spoke6 = new THREE.Mesh( geometry, material );
  scene.add( spoke6 );
  spoke6.position.x = 1.7
  spoke6.position.y = -1.2
  spoke6.position.z = 0
  spoke6.rotation.x = (2/3)*Math.PI

  var geometry = new THREE.CylinderGeometry( 0.1, 0.1, 12, 32, 32);
  var material = new THREE.MeshBasicMaterial( {color: 0x777777} );
  var flagpole = new THREE.Mesh( geometry, material );
  scene.add( flagpole );
  flagpole.position.x = -5
  flagpole.position.y = 2
  flagpole.position.z = -4

  var geometry = new THREE.PlaneBufferGeometry(3, 0.5)
  var material = new THREE.MeshBasicMaterial({color: 0xff0000})
  var flag1 = new THREE.Mesh(geometry, material)
  scene.add(flag1)
  flag1.position.y = 7.75
  flag1.position.z = -4
  flag1.position.x = -3.6

  var geometry = new THREE.PlaneBufferGeometry(3, 0.5)
  var material = new THREE.MeshBasicMaterial({color: 0xffffff})
  var flag2 = new THREE.Mesh(geometry, material)
  scene.add(flag2)
  flag2.position.y = 7.25
  flag2.position.z = -4
  flag2.position.x = -3.6

  var geometry = new THREE.PlaneBufferGeometry(3, 0.5)
  var material = new THREE.MeshBasicMaterial({color: 0x0000ff})
  var flag3 = new THREE.Mesh(geometry, material)
  scene.add(flag3)
  flag3.position.y = 6.75
  flag3.position.z = -4
  flag3.position.x = -3.6

  var geometry = new THREE.PlaneBufferGeometry(3, 0.5)
  var material = new THREE.MeshBasicMaterial({color: 0xff0000})
  var flag4 = new THREE.Mesh(geometry, material)
  scene.add(flag4)
  flag4.position.y = 7.75
  flag4.position.z = -4
  flag4.position.x = -3.6
  flag4.rotation.y = Math.PI

  var geometry = new THREE.PlaneBufferGeometry(3, 0.5)
  var material = new THREE.MeshBasicMaterial({color: 0xffffff})
  var flag5 = new THREE.Mesh(geometry, material)
  scene.add(flag5)
  flag5.position.y = 7.25
  flag5.position.z = -4
  flag5.position.x = -3.6
  flag5.rotation.y = Math.PI

  var geometry = new THREE.PlaneBufferGeometry(3, 0.5)
  var material = new THREE.MeshBasicMaterial({color: 0x0000ff})
  var flag6 = new THREE.Mesh(geometry, material)
  scene.add(flag6)
  flag6.position.y = 6.75
  flag6.position.z = -4
  flag6.position.x = -3.6
  flag6.rotation.y = Math.PI

  var geometry = new THREE.SphereGeometry( 0.5, 32, 32 );
  var material = new THREE.MeshBasicMaterial( {color: 0x3b3b3b} );
  var cannonball1 = new THREE.Mesh( geometry, material );
  scene.add( cannonball1 );
  cannonball1.position.y = -3
  cannonball1.position.z = 2.2
  cannonball1.position.x = 5

  var geometry = new THREE.SphereGeometry( 0.5, 32, 32 );
  var material = new THREE.MeshBasicMaterial( {color: 0x3d3d3d} );
  var cannonball2 = new THREE.Mesh( geometry, material );
  scene.add( cannonball2 );
  cannonball2.position.y = -3
  cannonball2.position.z = 2.2
  cannonball2.position.x = 6

  var geometry = new THREE.SphereGeometry( 0.5, 32, 32 );
  var material = new THREE.MeshBasicMaterial( {color: 0x404040} );
  var cannonball3 = new THREE.Mesh( geometry, material );
  scene.add( cannonball3 );
  cannonball3.position.y = -3
  cannonball3.position.z = 2.2
  cannonball3.position.x = 4

  var geometry = new THREE.SphereGeometry( 0.5, 32, 32 );
  var material = new THREE.MeshBasicMaterial( {color: 0x383838} );
  var cannonball4 = new THREE.Mesh( geometry, material );
  scene.add( cannonball4 );
  cannonball4.position.y = -3
  cannonball4.position.z = 3.2
  cannonball4.position.x = 5.5

  var geometry = new THREE.SphereGeometry( 0.5, 32, 32 );
  var material = new THREE.MeshBasicMaterial( {color: 0x3b3b3b} );
  var cannonball5 = new THREE.Mesh( geometry, material );
  scene.add( cannonball5 );
  cannonball5.position.y = -3
  cannonball5.position.z = 3.2
  cannonball5.position.x = 4.5

  var geometry = new THREE.SphereGeometry( 0.5, 32, 32 );
  var material = new THREE.MeshBasicMaterial( {color: 0x3d3d3d} );
  var cannonball6 = new THREE.Mesh( geometry, material );
  scene.add( cannonball6 );
  cannonball6.position.y = -3
  cannonball6.position.z = 4.2
  cannonball6.position.x = 5

  var geometry = new THREE.SphereGeometry( 0.5, 32, 32 );
  var material = new THREE.MeshBasicMaterial( {color: 0x404040} );
  var cannonball7 = new THREE.Mesh( geometry, material );
  scene.add( cannonball7 );
  cannonball7.position.y = -2.2
  cannonball7.position.z = 2.45
  cannonball7.position.x = 5.5

  var geometry = new THREE.SphereGeometry( 0.5, 32, 32 );
  var material = new THREE.MeshBasicMaterial( {color: 0x383838} );
  var cannonball8 = new THREE.Mesh( geometry, material );
  scene.add( cannonball8 );
  cannonball8.position.y = -2.2
  cannonball8.position.z = 2.45
  cannonball8.position.x = 4.5

  var geometry = new THREE.SphereGeometry( 0.5, 32, 32 );
  var material = new THREE.MeshBasicMaterial( {color: 0x3b3b3b} );
  var cannonball9 = new THREE.Mesh( geometry, material );
  scene.add( cannonball9 );
  cannonball9.position.y = -2.2
  cannonball9.position.z = 3.45
  cannonball9.position.x = 5

  var geometry = new THREE.SphereGeometry( 0.5, 32, 32 );
  var material = new THREE.MeshBasicMaterial( {color: 0x3d3d3d} );
  var cannonball10 = new THREE.Mesh( geometry, material );
  scene.add( cannonball10 );
  cannonball10.position.y = -1.4
  cannonball10.position.z = 2.90
  cannonball10.position.x = 5

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross01 = new THREE.Mesh( geometry, material );
  scene.add( cross01 );
  cross01.position.x = 0
  cross01.position.y = -2.5
  cross01.position.z = -25

  var geometry = new THREE.BoxGeometry( 3, 1, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross11 = new THREE.Mesh( geometry, material );
  scene.add( cross11 );
  cross11.position.x = 0
  cross11.position.y = -1.5
  cross11.position.z = -25

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross02 = new THREE.Mesh( geometry, material );
  scene.add( cross02 );
  cross02.position.x = -25
  cross02.position.y = -2.5
  cross02.position.z = -25
  cross02.rotation.y = 0.25*Math.PI

  var geometry = new THREE.BoxGeometry( 3, 1, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross12 = new THREE.Mesh( geometry, material );
  scene.add( cross12 );
  cross12.position.x = -25
  cross12.position.y = -1.5
  cross12.position.z = -25
  cross12.rotation.y = 0.25*Math.PI

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross03 = new THREE.Mesh( geometry, material );
  scene.add( cross03 );
  cross03.position.x = -25
  cross03.position.y = -2.5
  cross03.position.z = 0

  var geometry = new THREE.BoxGeometry( 1, 1, 3 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross13 = new THREE.Mesh( geometry, material );
  scene.add( cross13 );
  cross13.position.x = -25
  cross13.position.y = -1.5
  cross13.position.z = 0

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross04 = new THREE.Mesh( geometry, material );
  scene.add( cross04 );
  cross04.position.x = -25
  cross04.position.y = -2.5
  cross04.position.z = 25
  cross04.rotation.y = -0.25*Math.PI

  var geometry = new THREE.BoxGeometry( 3, 1, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross14 = new THREE.Mesh( geometry, material );
  scene.add( cross14 );
  cross14.position.x = -25
  cross14.position.y = -1.5
  cross14.position.z = 25
  cross14.rotation.y = -0.25*Math.PI

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross05 = new THREE.Mesh( geometry, material );
  scene.add( cross05 );
  cross05.position.x = 0
  cross05.position.y = -2.5
  cross05.position.z = 25

  var geometry = new THREE.BoxGeometry( 3, 1, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross15 = new THREE.Mesh( geometry, material );
  scene.add( cross15 );
  cross15.position.x = 0
  cross15.position.y = -1.5
  cross15.position.z = 25

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross06 = new THREE.Mesh( geometry, material );
  scene.add( cross06 );
  cross06.position.x = 25
  cross06.position.y = -2.5
  cross06.position.z = -25
  cross06.rotation.y = -0.25*Math.PI

  var geometry = new THREE.BoxGeometry( 3, 1, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross16 = new THREE.Mesh( geometry, material );
  scene.add( cross16 );
  cross16.position.x = 25
  cross16.position.y = -1.5
  cross16.position.z = -25
  cross16.rotation.y = -0.25*Math.PI

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross07 = new THREE.Mesh( geometry, material );
  scene.add( cross07 );
  cross07.position.x = 25
  cross07.position.y = -2.5
  cross07.position.z = 0

  var geometry = new THREE.BoxGeometry( 1, 1, 3 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross17 = new THREE.Mesh( geometry, material );
  scene.add( cross17 );
  cross17.position.x = 25
  cross17.position.y = -1.5
  cross17.position.z = 0

  var geometry = new THREE.BoxGeometry( 1, 5, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross08 = new THREE.Mesh( geometry, material );
  scene.add( cross08 );
  cross08.position.x = 25
  cross08.position.y = -2.5
  cross08.position.z = 25
  cross08.rotation.y = 0.25*Math.PI

  var geometry = new THREE.BoxGeometry( 3, 1, 1 );
  var material = new THREE.MeshBasicMaterial( {color: 0xffffff} );
  var cross18 = new THREE.Mesh( geometry, material );
  scene.add( cross18 );
  cross18.position.x = 25
  cross18.position.y = -1.5
  cross18.position.z = 25
  cross18.rotation.y = 0.25*Math.PI
}

function CheckCollision(){
  if(camera.position.z < -28){
    camera.position.z = -28
  }
  if(camera.position.z > 28){
    camera.position.z = 28
  }
  if(camera.position.x < -28){
    camera.position.x = -28
  }
  if(camera.position.x > 28){
    camera.position.x = 28
  }
  if(camera.position.z < 9.5 && camera.position.z > 8.5 && camera.position.x < 9.5 && camera.position.x > -9.5){
    camera.position.z = 9.5
  }
  if(camera.position.z > -9.5 && camera.position.z < -8.5 && camera.position.x < 9.5 && camera.position.x > -9.5){
    camera.position.z = -9.5
  }
  if(camera.position.x < 9.5 && camera.position.x > 8.5 && camera.position.z < 9.5 && camera.position.z > -9.5){
    camera.position.x = 9.5
  }
  if(camera.position.x > -9.5 && camera.position.x < -8.5 && camera.position.z < 9.5 && camera.position.z > -9.5){
    camera.position.x = -9.5
  }
}

function BlackScreen(){
  blackscreen.rotation.y = camera.rotation.y
  blackscreen.position.x = camera.position.x - Math.sin(camera.rotation.y)/2
  blackscreen.position.y = camera.position.y
  blackscreen.position.z = camera.position.z - Math.cos(camera.rotation.y)/2

  if(safe > 0){
    material1.opacity = opacity - 1
  }

  document.getElementById("title").style.opacity = opacity

  if(opacity > 0 && safe > 0){
    opacity -= 1/180
    safe -= 1/180
  }
}

function CheckText(){
  if(opacity > 0){
    opacity -= 1/180
    safe -= 1/180
  }else{
    opacity = 0
  }
  if(camera.position.x < 5 && camera.position.x > -5 && camera.position.z < -20 && camera.position.z > -30){
    DrawText("Zij hebben in de oorlog")
  }else if(camera.position.x < 5 && camera.position.x > -5 && camera.position.z > 20 && camera.position.z < 30){
    DrawText("Hier staan we dan bij")
  }else if(camera.position.z < 5 && camera.position.z > -5 && camera.position.x < -20 && camera.position.x > -30){
    DrawText("met namen erop die niemand")
  }else if(camera.position.z < 5 && camera.position.z > -5 && camera.position.x > 20 && camera.position.x < 30){
    DrawText("zodat wij nu hier in")
  }else if(camera.position.x < 30 && camera.position.x > 20 && camera.position.z < -20 && camera.position.z > -30){
    DrawText("hun leven moeten geven,")
  }else if(camera.position.x < 30 && camera.position.x > 20 && camera.position.z > 20 && camera.position.z < 30){
    DrawText("vrijheid mogen leven.")
  }else if(camera.position.z < 30 && camera.position.z > 20 && camera.position.x < -20 && camera.position.x > -30){
    DrawText("het herdenkingsmonument,")
  }else if(camera.position.z > -30 && camera.position.z < -20 && camera.position.x < -20 && camera.position.x > -30){
    DrawText("van ons heeft gekend.")
  }
}

function DrawText(text){
  if(opacity < 1){
    opacity += 1/90
  }
  document.getElementById('title').innerHTML = text
}